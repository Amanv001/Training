<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "studentadmission";

    $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
?>